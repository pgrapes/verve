import PageManager from '../page-manager';

export default class RSS extends PageManager {}

