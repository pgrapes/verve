import $ from 'jquery';



export default function() {
    
 // Close Button
 
var pcartClose = document.getElementById('vr-close');
  if($(pcartClose).length) {
 	  pcartClose.addEventListener('click', function() {
		
		
     $('.toggle-menu-checkbox').prop('checked', false);
	 
 });
}
}