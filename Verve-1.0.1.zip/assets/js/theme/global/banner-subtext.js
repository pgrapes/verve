import $ from 'jquery';


export default function() {
   
	$('.info-block').each(function() {
		
		const $upperLine = $(this).find('.subber');
		
		const strB = $(this).find('h1').text();
		const strC =  $(this).find('h1');
		const str = strB.substring(strB.indexOf("|") + 1);
		const strP = strB.substring(strB.indexOf("|") + 0);
		$($upperLine).before('<p>'+str+'</p>');
		
		$('.info-block h1.subber').each(function() {
			
			//if($(this).text().contains("|")) {
		 $(this).text($(this).text().split(strP).join(""));
	// }
	 });
  
  
});
   
}

