import $ from 'jquery';
import utils from '@bigcommerce/stencil-utils';


export default function() {
	 const $cartprev = $('.vr-cartprev');
	 const $header = $('header');
   $($cartprev).on('click', '.vr-remove', (event) => {
	    event.preventDefault();
        const cartItemId = $(event.currentTarget).data('cart-itemid');

		   
        
        $(event.currentTarget).css('background-color', '#f89dba');
    
     const newQty = 0;
   
     utils.api.cart.itemRemove(cartItemId, (err, response) => {
          const $modalOverlay = $('.loadingOverlay');
             $('.previewCartItem a[data-cart-itemId = '+cartItemId+']').closest('li').addClass('vr-removing animated fadeOutRight');
		     const options = {
		         template: 'common/cart-preview',
        
		         config: {
		             cart: {
		                 suggestions: {
		                     limit: 6,
		                 },
		             },
		         },
		     };
		     utils.api.cart.getContent(options, (err, response) => {
		         // Insert fetched content into modal
         $modalOverlay.show();
		         $('.vr-cartprev .modal-content').html(response);
				  $modalOverlay.hide();
				var cartClose = document.getElementById('vr-close');
				 	  cartClose.addEventListener('click', function() {

				     $('.toggle-menu-checkbox').prop('checked', false);

				 });
		 });
         
		 
             // Update cart counter
             //const $body = $('body');
             const $cartQuantity = $('.vr-cartprev .modal-content[data-cart-quantity]');
             const $cartCounter = $('.navUser-action.cart-count');
             const quantity = $cartQuantity.data('cart-quantity');

             //$cartCounter.addClass('cart-count--positive');
             $header.trigger('cart-quantity-update', quantity);
       
        
     });

   
	 });

}