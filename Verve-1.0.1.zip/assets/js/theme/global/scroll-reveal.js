import $ from 'jquery';
import ScrollReveal from 'scrollreveal';

export default function() {

	window.sr = ScrollReveal();
    if (sr.isSupported()) {
           document.documentElement.classList.add('sr');
         }
	sr.reveal('.herCarousel .info-block', { origin: 'bottom', distance: '100px' });
	sr.reveal('.vr-home.top-block', { origin: 'top', distance: '100px' });
	sr.reveal('.vr-featured .productCarousel-slide', 300);
	sr.reveal('.vr-new-products .productCarousel-slide', 300);
	sr.reveal('.verve-sub .productCarousel-slide', 300);
	sr.reveal('.productGrid .product', 300);
	sr.reveal('.brands .slide', 160);
}