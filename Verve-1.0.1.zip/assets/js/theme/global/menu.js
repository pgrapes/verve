import $ from 'jquery';



export default function() {
    
 // Close Button
 
var openMenu = document.getElementById('menu-opener');
 	  openMenu.addEventListener('click', function() {
		
     $('body').toggleClass('active3');
	 
 });
 
 $('.container-menu li a').each(function(){
	if($(this).is("a:contains('*')")) {
		$(this).wrap('<h3>');
	    $(this).html($(this).html().split('*').join(''));
	}
});

}