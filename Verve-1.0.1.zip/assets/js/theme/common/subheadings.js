import $ from 'jquery';

export default function() {
    const subTitle =  $('.product-title h1');
	const newSub =  $('.item-block .container h2').text();
	$(subTitle).after('<p>'+newSub+'</p>');
	
}
