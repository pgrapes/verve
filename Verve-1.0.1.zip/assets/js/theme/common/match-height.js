import $ from 'jquery';
import 'jquery-match-height';

export default function() {
    const $slide = $('.slide');
	const $product = $('.productGrid .product');
    $($product).matchHeight({
    byRow: false,
    property: 'height',
    target: null,
    remove: false
});
    $($slide).matchHeight();
	
}

