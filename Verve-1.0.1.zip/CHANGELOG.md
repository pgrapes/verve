Passing validation

-----------------------------------------------------------------------------------------
Version 1.01
-----------------------------------------------------------------------------------------

Re: Subcategory navigation works/is present

- The theme has a custom overlay menu.  I’d like users to be able to lay categories out custom/evenly according to how many items are in a category. http://verve.mybigcommerce.com  I can detail it in the docs.



Re: Images don’t appear in banners

- They seem to appear for me. Perhaps I’m looking in the wrong place.





